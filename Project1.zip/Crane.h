#pragma once
#include "Model.h"
class Crane 	
{
	float currentRotation;
	Model base;
	Model turret;
public:
	Crane() {};
	void load();
	virtual ~Crane();
	void rotateZ(float angle);
	void rotateX(float angle);
	void drawModel(Shader& ourShader);
};

